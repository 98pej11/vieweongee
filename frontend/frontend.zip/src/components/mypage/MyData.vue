<template>
  <div>
    <!-- <div>
      <el-calendar :range="[new Date(2019, 2, 4), new Date(2019, 2, 24)]" />
    </div> -->
    <el-container>
      <el-main class="outline-box">
        <h2 class="text-h6 mb-3">스터디 내역 조회</h2>
        <el-table
      class="el-table"
      :span-method="objectSpanMethod"
      :data="tableData"
      style="width: 100%; text-align: center;"
      :class="tableRowClassName"
      
    >
      <el-table-column prop="type" label="날짜" width="180" />
      <el-table-column prop="type" label="기업명" width="220" />
      <el-table-column prop="name1" label="항목" width="500" />
      <!-- 버튼 -->
      <el-table-column prop="type" label="버튼" width="" >
        <el-button link type="primary" size="small" @click="handleClick"
          >Detail</el-button
        >
      </el-table-column>
    </el-table>
      </el-main>
    </el-container>
    
  </div>
</template>

<script>
import { defineComponent } from "vue";

export default defineComponent({
  name: "MyData",
});
</script>
<style scoped>
h2 {
  text-align: center;
}
.el-container {
  margin: 0 auto;
  margin-top: 2%;
  margin-bottom: 2%;
  width: 80%;
}

p {
  /* float: left; */
  margin: 30px 0 10px 0;
}
.el-dialog {
  display: flex;
}
.confirm-btn {
  color: white;
  width: 30%;
}
.el-button:not(.confirm-btn) {
  width: 96%;
  margin-top: 30px;
  color: white;
}
.el-select {
  width: 100%;
}
.el-table .warning-row {
  --el-table-tr-bg-color: var(--el-color-warning-light-9);
}
</style>
