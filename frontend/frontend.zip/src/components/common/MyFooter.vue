<template>
  <div id="Footer">
    <footer>
      <div class="”footer-content”">
        <h3>Foolish Developer</h3>
        <p>Foolish Developer — source code.</p>
      </div>
      <ul class="”socials”">
        <li><a href="”#”" class="”fa" fa-facebook”></a></li>
        <li><a href="”#”" class="”fa" fa-twitter”></a></li>
        <li><a href="”#”" class="”fa" fa-google-plus></a></li>
        <li><a href="”#”" class="”fa" fa-youtube”></a></li>
        <li><a href="”#”" class="”fa" fa-linkedin-square></a></li>
      </ul>
    </footer>
  </div>
</template>

<script type="ts">
export default {
  name: "MyFooter",
};
</script>

<style scoped>
footer {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background: #111;
  height: auto;
  width: 100vw;
  padding-top: 40px;
  color: black;
}
.footer-content {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  text-align: center;
}
.footer-content h3 {
  font-size: 2.1rem;
  font-weight: 500;
  text-transform: capitalize;
  line-height: 3rem;
}
.footer-content p {
  max-width: 500px;
  margin: 10px auto;
  line-height: 28px;
  font-size: 14px;
  color: #cacdd2;
}

.socials {
  list-style: none;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 1rem 0 3rem 0;
}

.socials li {
  margin: 0 10px;
}

.socials a {
  text-decoration: none;
  color: #fff;
  border: 1.1px solid white;
  padding: 5px;
  border-radius: 50%;
}

.socials a i {
  font-size: 1.1rem;
  width: 20px;
  transition: color 0.4s ease;
}

.socials a:hover i {
  color: aqua;
}
</style>
