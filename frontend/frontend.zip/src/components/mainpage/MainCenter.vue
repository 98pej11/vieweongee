<template>
    <div class="MainCenter">
       <div>
         <img src="@/assets/image/logo_mascot.png" />
       </div>
       <div>
         <img src="@/assets/image/logo_vieweongee.png" />
       </div>
   </div>
</template>
<script  >
import {defineComponent} from 'vue'

export default defineComponent({
    name: 'MainCenter',
})

</script>
