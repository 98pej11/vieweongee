<template>
    <div class="login">
      <UserLogin />
      <!--<SearchBar /> -->
    </div>
  </template>
  
  <script>
  import {defineComponent} from 'vue';
  import UserLogin from '@/components/user/UserLogin.vue';
  
  export default defineComponent({
    components: {
      UserLogin
    },
    
  }) 
  </script>
  <style scoped>
  .MainCenter{
    text-align: center;
  }
  </style>